# Update Phone System: Full Company Directory + Natural Voice + Conversational Greeting

## What to do

Read all files in `uploads/voice/` and integrate them into the existing Next.js project. These files define a Twilio IVR phone system with a 30-person company directory, natural-sounding generative voice, and a conversational greeting.

## File placement

### Library files → project's `lib/` directory
- `uploads/voice/phone-config.ts` → `lib/phone-config.ts` (REPLACE if exists)
- `uploads/voice/twiml.ts` → `lib/twiml.ts` (REPLACE if exists)

### API routes → `app/api/voice/` (create directories as needed)
Each file becomes `route.ts` inside its named directory:

- `uploads/voice/incoming.ts` → `app/api/voice/incoming/route.ts`
- `uploads/voice/menu.ts` → `app/api/voice/menu/route.ts`
- `uploads/voice/operator.ts` → `app/api/voice/operator/route.ts`
- `uploads/voice/operator-status.ts` → `app/api/voice/operator-status/route.ts`
- `uploads/voice/directory.ts` → `app/api/voice/directory/route.ts`
- `uploads/voice/directory-route.ts` → `app/api/voice/directory-route/route.ts`
- `uploads/voice/voicemail.ts` → `app/api/voice/voicemail/route.ts`
- `uploads/voice/voicemail-complete.ts` → `app/api/voice/voicemail-complete/route.ts`
- `uploads/voice/voicemail-transcription.ts` → `app/api/voice/voicemail-transcription/route.ts`

### Fix import paths
Check `tsconfig.json` for how `@/` is aliased. If the project uses `src/`, adjust all paths accordingly.

## IMPORTANT: Voice and language consistency

The system uses `Polly.Joanna-Generative` for natural-sounding speech. This requires a `language` attribute on every `<Say>` tag.

The `say()` helper in `twiml.ts` accepts three arguments: `say(text, voice, language)`.

**After placing files, check ALL route files and ensure every `say()` call passes all three arguments:**
```typescript
const v = phoneConfig.voice;
const lang = phoneConfig.voiceLanguage;

say("Hello", v, lang)  // CORRECT
say("Hello", v)         // WRONG — will break generative voice
```

If any route file only passes two arguments to `say()`, add the `lang` parameter. Every route file should declare `const lang = phoneConfig.voiceLanguage;` alongside `const v = phoneConfig.voice;`.

## Key design decisions to preserve

### Conversational greeting (no "press 1, press 2" menu)
The greeting says:
> "Welcome to Voyage Advisory. You can ask to learn about our services, ask to speak with a specific person, ask to talk to sales, or just say help and we'll connect you with someone right away."

Callers respond naturally. The menu handler routes based on what they say:
- "learn about your services" / "what do you do" → services overview
- "speak with Karen Gliwa" / "can I talk to Jerrod" → routes directly to that person (skips directory prompt)
- "sales" / "pricing" → rings Andrew + Bryan Hayden (Sales Director)
- "help" / "operator" / press 0 → rings Andrew + Emma simultaneously
- "directory" / press 2 → goes to the directory prompt for name/extension search

### Smart name detection from main menu
If someone says "Can I speak with Karen Gliwa" at the main greeting, the menu handler detects the name and routes directly to directory-route with the name as a query parameter. The caller does NOT hear "Company directory, please say the name..." — they go straight to "Connecting you to Karen Gliwa."

### Directory search is name-based, NOT "press 1 for X"
The directory prompt says: "Please say the name of the person you are trying to reach, or enter their three digit extension."

### Call routing groups

**Sales / services / learn more path** → rings Andrew (312.212.0815) + David (920.691.6440) simultaneously
- Triggered by: "learn about services", "sales", "pricing", "business development", "what do you do", press 1

**Operator / help / catch-all path** → rings Andrew (312.212.0815) + Emma (240.440.1901) + Olivia (712.344.0077) simultaneously
- Triggered by: "help", "operator", press 0, unrecognized input

**Both paths**: if no one answers within 25 seconds → voicemail → transcribed → emailed to hello@voyageadvisory.com via Resend API
### Caller ID passthrough on directory calls
Directory calls show the ACTUAL CALLER'S phone number to the team member, not the Voyage number. The `<Dial>` in directory-route.ts intentionally has no `callerId` attribute.

### Randy/Holly Tran
Extension 528 has `aliases: ["Randy", "Holly"]`. Either name matches.

### Two Sarahs, two Harrys
Disambiguation handled automatically — if caller says "Sarah", they hear both options with titles and extensions.

## Environment variables

Add to `.env.local`:
```
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_PHONE_NUMBER=+1XXXXXXXXXX
OPERATOR_PHONE_1=+13122120815
OPERATOR_PHONE_2=+12404401901
OPERATOR_PHONE_3=+17123440077
SALES_PHONE_1=+13122120815
SALES_PHONE_2=+19206916440
PHONE_SYSTEM_BASE_URL=https://voyage-app-store.vercel.app
RESEND_API_KEY=re_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
VOICEMAIL_FROM_EMAIL=onboarding@resend.dev
```

## Verification

After placing all files:

1. `npm run build` — confirm no TypeScript or import errors
2. `npm run dev` and test:

```bash
# Main greeting (should be conversational, not "press 1, press 2")
curl -X POST http://localhost:3000/api/voice/incoming

# "Learn about services"
curl -X POST http://localhost:3000/api/voice/menu -d "SpeechResult=tell me about your services"

# "Speak with Karen" — should route directly, no directory prompt
curl -X POST http://localhost:3000/api/voice/menu -d "SpeechResult=can I speak with Karen Gliwa"

# "Sales" — should ring Andrew + Bryan
curl -X POST http://localhost:3000/api/voice/menu -d "SpeechResult=sales"

# "Help" — should ring Andrew + Emma
curl -X POST http://localhost:3000/api/voice/menu -d "SpeechResult=help"

# Directory by extension
curl -X POST http://localhost:3000/api/voice/directory-route -d "Digits=504"

# Directory by name
curl -X POST http://localhost:3000/api/voice/directory-route -d "SpeechResult=Jerrod Rogers"

# Ambiguous name (two Sarahs)
curl -X POST http://localhost:3000/api/voice/directory-route -d "SpeechResult=Sarah"

# Alias (Holly = Randy/Holly Tran)
curl -X POST http://localhost:3000/api/voice/directory-route -d "SpeechResult=Holly"
```

3. All responses should be valid TwiML with `voice="Polly.Joanna-Generative"` and `language="en-US"` on every `<Say>` tag

## Do NOT
- Do not install the Twilio Node.js SDK
- Do not modify existing routes or files outside of `app/api/voice/` and `lib/`
- Do not commit real API keys
- Do not change the greeting to a "press 1 for X" style
- Do not use `Polly.Joanna` (standard) — always use `Polly.Joanna-Generative`
